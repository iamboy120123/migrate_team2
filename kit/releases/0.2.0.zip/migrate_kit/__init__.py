"""Versioned, standard-library-only migration simulation kit."""
__version__ = "0.2.0"
