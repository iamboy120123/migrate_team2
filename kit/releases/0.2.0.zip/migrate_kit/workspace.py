from __future__ import annotations

import csv
import io
import json
import os
import shutil
import subprocess
import sys
import zipfile
from pathlib import Path

from . import __version__
from .storage import (WorkspaceError, digest, file_map, find_job, fingerprint, inside,
                      jobs, now, object_digest, read, safe_name, text, write)


def initialize(root):
    """Add missing scaffolding only. Never replace existing workspace settings."""
    for folder in ("projects", "registry", ".cache/kit", "kit/releases", "shared/policies",
                   "shared/knowledge", "shared/target/_incoming"):
        (root / folder).mkdir(parents=True, exist_ok=True)
    defaults = {
        "workspace.json": {"workspace_version": "0.1.0", "mode": "simulation", "created_at": now()},
        "shared/team.json": {"github_mode": "manual", "db_mode": "human", "simulation_only": True,
                             "ids": {"base": 90000, "step": 1000}},
        "shared/approvers.json": {"simulation_reviewers": ["DEMO_SA"], "production_approvers": []},
    }
    for name, value in defaults.items():
        if not (root / name).exists():
            write(root / name, value)
    return defaults


def release_files(root):
    files = {p.relative_to(root / "kit/src").as_posix(): p.read_bytes()
             for p in sorted((root / "kit/src").rglob("*.py")) if "__pycache__" not in p.parts}
    for group in ("templates", "ai", "knowledge"):
        folder = root / "kit" / group
        if folder.exists():
            for path in sorted(folder.rglob("*")):
                if path.is_file():
                    files[f"migrate_kit/resources/{group}/{path.relative_to(folder).as_posix()}"] = path.read_bytes()
    return files


def archive_bytes(files):
    """Deterministic release archive. STORED (no compression) since 0.2.0: identical bytes on every
    machine and zlib build, so any clone can rebuild and verify a release (ADR-007)."""
    buffer = io.BytesIO()
    with zipfile.ZipFile(buffer, "w", compression=zipfile.ZIP_STORED) as archive:
        for name, data in sorted(files.items()):
            info = zipfile.ZipInfo(name, (2026, 1, 1, 0, 0, 0))
            info.compress_type = zipfile.ZIP_STORED
            info.external_attr = 0o644 << 16
            archive.writestr(info, data)
    return buffer.getvalue()


AI_PREFIX = "migrate_kit/resources/ai/claude/"
KNOWLEDGE_PREFIX = "migrate_kit/resources/knowledge/"
JOB_EDITABLE_KNOWLEDGE = {"knowledge/WORKFLOW.md", "knowledge/lessons-learned.md", "knowledge/glossary-kit.md"}


def install_ai_context(job, archive_path, values):
    """Copy the release's AI context (.claude) and knowledge into a new job; return the locked file hashes.

    Text is rendered with {{PROJECT}}/{{JOB}}/{{KIT}}. Locked files (.claude/** and knowledge/reference/**,
    not CLAUDE.md or the job-editable knowledge pages) are verified by `check`; changing them needs a new
    kit release, not a local edit.
    """
    import hashlib
    locked = {}
    with zipfile.ZipFile(archive_path) as archive:
        for name in sorted(archive.namelist()):
            if name.startswith(AI_PREFIX):
                rel = ".claude/" + name[len(AI_PREFIX):]
                if rel == ".claude/SOURCE.json":
                    continue
            elif name.startswith(KNOWLEDGE_PREFIX):
                rel = "knowledge/" + name[len(KNOWLEDGE_PREFIX):]
            else:
                continue
            data = archive.read(name)
            if rel.endswith((".md", ".js", ".json")):
                body = data.decode("utf-8")
                for key, value in values.items():
                    body = body.replace("{{" + key + "}}", value)
                data = body.encode("utf-8")
            target = inside(job, rel)
            target.parent.mkdir(parents=True, exist_ok=True)
            target.write_bytes(data)
            if rel not in JOB_EDITABLE_KNOWLEDGE:
                locked[rel] = hashlib.sha256(data).hexdigest()
        template = "migrate_kit/resources/templates/job/CLAUDE.md"
        if template in archive.namelist():
            body = archive.read(template).decode("utf-8")
            for key, value in values.items():
                body = body.replace("{{" + key + "}}", value)
            text(job / "CLAUDE.md", body)          # job notes may be added below; not locked
    return locked


def verify_ai_context(job):
    """Installed AI context must still match what the pinned kit installed (0.2.0+ jobs only)."""
    pin = read(job / "kit.lock.json")
    locked = pin.get("ai_context")
    if not locked:
        return
    changed = [rel for rel, sha in locked["files"].items()
               if not (job / rel).is_file() or digest(job / rel) != sha]
    if changed:
        raise WorkspaceError(f"Kit AI context/knowledge modified: {', '.join(sorted(changed)[:5])}"
                             f"{' …' if len(changed) > 5 else ''} — restore it; changes go through a new kit release")


def freeze(root):
    import hashlib
    files = release_files(root)
    blob = archive_bytes(files)
    sha = hashlib.sha256(blob).hexdigest()
    version = __version__
    release_path = root / "kit/releases" / f"{version}.json"
    relative = f".cache/kit/{version}/migrate_kit-{sha}.zip"
    if release_path.exists():
        prior = read(release_path)
        if prior["sha256"] != sha:
            raise WorkspaceError("This version is already frozen with different source. Bump kit version; do not overwrite a release.")
    artifact = root / relative
    if not artifact.exists():
        artifact.parent.mkdir(parents=True, exist_ok=True)
        artifact.write_bytes(blob)
    if digest(artifact) != sha:
        raise WorkspaceError("Cached release is corrupt; restore its original artifact")
    manifest = {"version": version, "sha256": sha, "artifact": relative,
                "kind": "simulation-kit", "files": {name: hashlib.sha256(data).hexdigest() for name, data in files.items()}}
    if not release_path.exists():
        write(release_path, manifest)
    return manifest


def snapshot(root, source=None):
    source = source or root / "samples/target"
    files = file_map(source)
    sid = "sim-" + object_digest(files)[:16]
    dest = root / "shared/target/snapshots" / sid
    if dest.exists():
        verify_snapshot(root, sid)
    else:
        dest.mkdir(parents=True)
        for name in files:
            target = inside(dest, name)
            target.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(inside(source, name), target)
        write(dest / "manifest.json", {"id": sid, "kind": "synthetic-target", "files": files,
                                       "sha256": object_digest(files), "production_verified": False})
    write(root / "shared/target/current.json", {"snapshot": sid})
    return sid


def verify_snapshot(root, sid):
    if not isinstance(sid, str) or not sid.startswith("sim-"):
        raise WorkspaceError("Expected a synthetic target snapshot")
    folder = inside(root / "shared/target/snapshots", sid)
    manifest = read(folder / "manifest.json")
    actual = {k: v for k, v in file_map(folder).items() if k != "manifest.json"}
    if actual != manifest["files"] or object_digest(actual) != manifest["sha256"]:
        raise WorkspaceError(f"Target snapshot modified: {sid}")
    return manifest


def verify_pin(root, job):
    pin = read(job / "kit.lock.json")
    release = read(root / "kit/releases" / f"{safe_version(pin['kit_version'])}.json")
    artifact = inside(root, release["artifact"])
    if pin["kit_sha256"] != release["sha256"] or digest(artifact) != pin["kit_sha256"]:
        raise WorkspaceError("Pinned kit hash does not match release artifact")
    target = verify_snapshot(root, pin["target_snapshot"])
    if target["sha256"] != pin["target_sha256"]:
        raise WorkspaceError("Pinned target hash does not match snapshot")
    return artifact


def safe_version(value):
    import re
    if not isinstance(value, str) or not re.fullmatch(r"\d+\.\d+\.\d+", value):
        raise WorkspaceError("Expected a numeric kit version")
    return value


def new_job(root, project, name, issue, workflow, owner="DEMO_DEVELOPER"):
    safe_name(project); safe_name(name); safe_name(owner)
    if issue < 1:
        raise WorkspaceError("Simulation issue number must be positive")
    path = root / "projects" / project / "jobs" / name
    if path.exists():
        raise WorkspaceError(f"Job already exists: {project}/{name}")
    for other in jobs(root):
        if read(other)["issue"] == issue:
            raise WorkspaceError(f"Issue/id range already reserved by {other.parent.name}")
    definition = read(workflow)
    if not definition.get("tasks"):
        raise WorkspaceError("Workflow must contain tasks")
    release = read(root / "kit/releases" / f"{__version__}.json")
    if digest(inside(root, release["artifact"])) != release["sha256"]:
        raise WorkspaceError("Cannot create a job from a modified release artifact")
    sid = read(root / "shared/target/current.json")["snapshot"]
    target = verify_snapshot(root, sid)
    for folder in ("config", "input/blendata", "input/run_results", "output", "status", "run_packs",
                   ".design", "knowledge", ".claude/commands"):
        (path / folder).mkdir(parents=True, exist_ok=True)
    team = read(root / "shared/team.json")
    write(path / "job.json", {"project": project, "job": name, "owner": owner, "issue": issue,
                               "issue_source": "simulation", "issue_unconfirmed": True,
                               "id_base": team["ids"]["base"] + issue * team["ids"]["step"],
                               "branch": f"job/{project}/{name}/R01", "round": "R01",
                               "mode": "simulation", "production_import_allowed": False, "created_at": now()})
    lock = {"kit_version": release["version"], "kit_sha256": release["sha256"],
            "target_snapshot": sid, "target_sha256": target["sha256"]}
    installed = install_ai_context(path, inside(root, release["artifact"]),
                                   {"PROJECT": project, "JOB": name, "KIT": release["version"]})
    if installed:
        lock["ai_context"] = {"files": installed, "sha256": object_digest(installed)}
    write(path / "kit.lock.json", lock)
    shutil.copy2(workflow, path / "input/blendata/export_workflow.json")
    write(path / "config/config.json", {"mode": "simulation", "package_name": "PKG_" + name.upper()[:26],
                                         "schema_mode": "simulation_unqualified", "db_mode": "human",
                                         "github_mode": "manual", "fixture": "fixtures/rows.json"})
    write(path / "status/approvals.json", {"mode": "simulation", "approvals": []})
    write(path / "status/events.json", [])
    for doc in ("INTAKE", "BUSINESS_RULES", "GAP_ANALYSIS", "OPEN_DECISIONS", "GATES",
                "IMPORT_LOG", "DEPLOY_LOG", "CUTOVER_RUNBOOK"):
        template = f"migrate_kit/resources/templates/status/{doc}.md"
        with zipfile.ZipFile(inside(root, release["artifact"])) as archive:
            content = archive.read(template).decode("utf-8") if template in archive.namelist() else f"# {doc}\n\nSimulation only. No production evidence recorded.\n"
        text(path / "status" / f"{doc}.md", content.replace("{{JOB}}", name))
    if not installed:   # releases without AI context (0.1.0 layout)
        text(path / "CLAUDE.md", f"# {project}/{name}\n\nSIMULATION ONLY. Never connect to Oracle/GitHub.\n"
             "Read kit.lock.json and status/ before work. Use the workspace launcher; do not duplicate kit code.\n"
             "A simulated approval is never an SA approval. Generated XML is not ODI Smart Export.\n")
        text(path / ".claude/commands/next-step.md", "Read job.json, kit.lock.json, status/GATES.md and the workspace README.\n"
             "Use `python <workspace>/tools/workspace.py status` to inspect the next simulation step.\n")
    text(path / "ROUNDS.md", "# Rounds\n\n| Round | Mode | Reason |\n|---|---|---|\n| R01 | simulation | Initial demonstration |\n")
    project_dir = path.parents[1] / "_project"
    for doc in ("DECISIONS", "glossary", "lessons-learned"):
        dest = project_dir / f"{doc}.md"
        if not dest.exists():
            text(dest, f"# {doc}\n\nProject: {project}\n")
    return path


def approve(root, job, reviewer):
    allowed = read(root / "shared/approvers.json")["simulation_reviewers"]
    if reviewer not in allowed:
        raise WorkspaceError("Reviewer is not in the simulation reviewer list")
    verify_pin(root, job)
    value = {"mode": "simulation", "approvals": [{"gate": "G2", "reviewer": reviewer,
             "state": "SIMULATED_APPROVAL", "fingerprint": fingerprint(job), "at": now(),
             "note": "Synthetic persona, not a real SA approval or deployment permission"}]}
    write(job / "status/approvals.json", value)
    return value


def simulate(root, job):
    artifact = verify_pin(root, job)
    # Actual execution imports the pinned ZIP, not mutable kit/src.
    bootstrap = "import sys;sys.path.insert(0,sys.argv.pop(1));from migrate_kit.runtime import main;main()"
    result = subprocess.run([sys.executable, "-B", "-X", "utf8", "-c", bootstrap,
                             str(artifact), str(root), str(job)], cwd=job, check=False)
    if result.returncode:
        raise WorkspaceError(f"Simulation failed/blocked (exit {result.returncode}); inspect status and output/verify")
    return read(job / "status/simulation.json")


def acquire_lock(root, job, holder):
    safe_name(holder)
    verify_pin(root, job)
    current = read(job / "status/simulation.json") if (job / "status/simulation.json").exists() else {}
    if current.get("fingerprint") != fingerprint(job) or current.get("state") != "SIMULATION_PASSED":
        raise WorkspaceError("Complete a current simulation before rehearsing import locking")
    lock = root / "registry/import_simulation.lock.json"
    payload = {"job": job.relative_to(root).as_posix(), "holder": holder, "at": now(), "mode": "simulation"}
    lock.parent.mkdir(parents=True, exist_ok=True)
    try:
        with lock.open("x", encoding="utf-8") as stream:
            json.dump(payload, stream, indent=2)
    except FileExistsError:
        raise WorkspaceError("Simulation import lock is occupied; inspect lock-status") from None
    return payload


def release_lock(root, job, holder):
    path = root / "registry/import_simulation.lock.json"
    if not path.exists():
        raise WorkspaceError("No simulation import lock is held")
    lock = read(path)
    if lock["holder"] != holder or lock["job"] != job.relative_to(root).as_posix():
        raise WorkspaceError("Only the same job and holder may release this simulation lock")
    events = read(job / "status/events.json")
    events.append({"event": "SIMULATED_IMPORT_REHEARSAL", "holder": holder, "at": now(),
                   "actual_odi_import": False, "note": "No connection or Smart Import was performed"})
    write(job / "status/events.json", events)
    text(job / "status/IMPORT_LOG.md", "# Import rehearsal\n\nSIMULATION ONLY — actual ODI import: NOT EXECUTED.\n\n" +
         "\n".join(f"- {e['at']} {e['holder']}: lock/unlock rehearsal, no ODI connection" for e in events) + "\n")
    path.unlink()


def check(root):
    issues, ranges, errors = set(), set(), []
    for path in jobs(root):
        job = path.parent
        try:
            meta = read(path)
            base = read(root / "shared/team.json")["ids"]
            if meta["issue"] in issues or meta["id_base"] in ranges:
                raise WorkspaceError("Duplicate issue/id range")
            if meta["id_base"] != base["base"] + meta["issue"] * base["step"]:
                raise WorkspaceError("Issue and id_base do not agree")
            issues.add(meta["issue"]); ranges.add(meta["id_base"])
            verify_pin(root, job)
            verify_ai_context(job)
            if meta.get("production_import_allowed") is not False or meta.get("mode") != "simulation":
                raise WorkspaceError("Simulation boundary modified")
            report = job / "status/simulation.json"
            if report.exists():
                state = read(report)
                if state["fingerprint"] != fingerprint(job):
                    raise WorkspaceError("STALE: inputs/config/pin changed; rerun review and simulation")
                for rel, sha in state.get("outputs", {}).items():
                    if digest(inside(job, rel)) != sha:
                        raise WorkspaceError(f"Generated evidence modified: {rel}")
                if state["state"] != "SIMULATION_PASSED":
                    raise WorkspaceError("Simulation is blocked or failed")
        except (WorkspaceError, OSError, ValueError, KeyError) as exc:
            errors.append(f"{job.name}: {exc}")
    return errors


def report(root):
    import html
    rows = []
    for path in jobs(root):
        meta = read(path); job = path.parent
        state = read(job / "status/simulation.json") if (job / "status/simulation.json").exists() else {}
        label = state.get("state", "NOT_RUN")
        if state and state.get("fingerprint") != fingerprint(job):
            label = "STALE_REVIEW_REQUIRED"
        pin = read(job / "kit.lock.json")
        rows.append({"project": meta["project"], "job": meta["job"], "owner": meta["owner"],
                     "kit": pin["kit_version"], "snapshot": pin["target_snapshot"], "state": label,
                     "import": "NOT_EXECUTED", "path": job.relative_to(root).as_posix()})
    errors = check(root)
    write(root / "registry/status.json", {"mode": "simulation", "jobs": rows, "errors": errors})
    lines = ["# Team simulation status", "", "SIMULATION ONLY — Oracle/Spark/ODI runtime: NOT EXECUTED.", "",
             "| Project | Job | Owner | Kit | State | Real import |", "|---|---|---|---|---|---|"]
    for row in rows:
        lines.append("| " + " | ".join(row[k] for k in ("project", "job", "owner", "kit", "state", "import")) + " |")
    if errors:
        lines += ["", "Integrity findings:"] + ["- " + x for x in errors]
    text(root / "STATUS.md", "\n".join(lines) + "\n")
    body = "".join("<tr>" + "".join(f"<td>{html.escape(row[k])}</td>" for k in
                   ("project", "job", "owner", "kit", "state", "import")) + "</tr>" for row in rows)
    text(root / "STATUS.html", '<!doctype html><html lang="th"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">'
         '<title>Migration team simulation</title><style>body{font:16px system-ui;background:#f3f6fb;color:#15233b;max-width:1200px;margin:40px auto;padding:20px}'
         'h1{font-size:30px}.notice{background:#fff0cb;padding:18px;border-radius:10px}table{width:100%;background:white;border-collapse:collapse;margin-top:24px}'
         'td,th{padding:14px;text-align:left;border-bottom:1px solid #dde4ed}th{background:#172c50;color:white}.flow{padding:24px 0;line-height:2}</style>'
         '<h1>Blendata → ODI · Team simulation</h1><div class="notice">จำลองออฟไลน์เท่านั้น · ไม่ได้ต่อ Oracle / Spark / ODI / GitHub<br>'
         'SIMULATION_PASSED หมายถึงชุดทดสอบข้อมูลตัวอย่างผ่าน ไม่ใช่การอนุมัติขึ้นระบบจริง</div>'
         '<div class="flow">Input → Pin kit & target → Review → SQL / DML → Simulation package → Fixture comparison → Import lock rehearsal</div>'
         '<table><thead><tr><th>Project</th><th>Job</th><th>Owner</th><th>Kit</th><th>Simulation</th><th>Real import</th></tr></thead><tbody>' + body +
         '</tbody></table><p>Integrity findings: ' + str(len(errors)) + '</p>' +
         '<ul>' + ''.join('<li>' + html.escape(x) + '</li>' for x in errors) + '</ul></html>')
    return rows


def demo(root):
    initialize(root); freeze(root); snapshot(root)
    for name, issue, owner in (("customer_daily", 101, "DEMO_ALICE"), ("order_daily", 102, "DEMO_BOB")):
        path = root / "projects/DEMO/jobs" / name
        if not path.exists():
            path = new_job(root, "DEMO", name, issue, root / "samples/workflows" / f"{name}.json", owner)
            approve(root, path, "DEMO_SA")
        simulate(root, path)
    report(root)
