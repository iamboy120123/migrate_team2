"""Versioned, standard-library-only migration simulation kit."""
__version__ = "0.1.0"
