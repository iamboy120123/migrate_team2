---
description: เช็คว่าของที่ AI ต้องใช้ครบหรือยัง ก่อน build package ที่ Smart Import ครั้งเดียว
---
<!-- KIT-BANNER {"scripts": ["scripts/checks/check_inputs.py"], "other": []} -->
กติกา: import เข้า ODI Studio ทำ **ครั้งเดียวตอนจบ** (Smart Import ไฟล์ `<package>.zip`) หลังจากนั้นเป็นเรื่องทดสอบ — ของทุกอย่างที่ AI ต้องใช้ต้องครบ *ก่อน* build

1. `python scripts/checks/check_inputs.py` (ไม่เขียนไฟล์ใด ๆ)
2. ถ้า `[พร้อม]` → ไป `/gen-export`
3. ถ้า `[ยังไม่พร้อม]` → สรุปรายการที่ขาดเป็นตารางเดียว (หมวด · ขาดอะไร · วิธีได้มา) แล้วถามผู้ใช้ **ทีละข้อ** ตามกฎ one-question-at-a-time (ใส่ [แนะนำ] + ตัวอย่างคำตอบ) · ข้อที่ต้องให้ผู้ใช้ไปเตรียมไฟล์ ให้บอก path เต็มและวิธี export
4. ห้ามเดา ห้ามหยิบไฟล์จาก repository/โปรเจกต์อื่นมาแทน ห้ามให้ผู้ใช้ import เพื่อ "ลองดู" — รัน `check_inputs.py` ซ้ำจนครบ
